"""farm_link URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path

from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.login1),
    path('login1_post',views.login1_post),
    path('admin_home',views.admin_home),
    path('farmer_home',views.farmer_home),
    path('export_reg',views.export_reg),
    path('view_exporter',views.view_exporter),
    path('approve_exporter/<id>',views.approve_exporter),
    path('reject_exporter/<id>',views.reject_exporter),
    path('view_verified_exporter',views.view_verified_exporter),
    path('add_notification',views.add_notification),
    path('add_notification_post',views.add_notification_post),
    path('view_notification',views.view_notification),
    path('delete_notification/<id>',views.delete_notification),
    path('exporter_reg',views.exporter_reg),
    path('exporter_reg_post',views.exporter_reg_post),
    path('farmer_view_notification',views.farmer_view_notification),
    path('view_crops',views.view_crops),
    path('view_fertilizer',views.view_fertilizer),
    path('view_pesticides',views.view_pesticides),
    path('add_government_policies',views.add_government_policies),
    path('add_government_policies_post',views.add_government_policies_post),
    path('edit_policy/<id>',views.edit_policy),
    path('edit_policy_post/<id>',views.edit_policy_post),
    path('delete_policy/<id>',views.delete_policy),
    path('admin_view_policy',views.admin_view_policy),
    path('login2',views.login2),
    path('farmer_view_policy',views.farmer_view_policy),
    path('exporter_view_profile',views.exporter_view_profile),
    path('exporter_edit_profile',views.exporter_edit_profile),
    path('add_requirement',views.add_requirement),
    path('view_requirement',views.view_requirement),
    path('edit_requirement',views.edit_requirement),
    path('delete_requirement',views.delete_requirement),
    path('farmer_view_requirement',views.farmer_view_requirement),
    path('send_availabilty/<id>',views.send_availabilty),
    path('send_availabilty_post/<id>',views.send_availabilty_post),
]
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)