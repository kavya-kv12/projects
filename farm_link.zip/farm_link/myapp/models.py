from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class farmer(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    house_name=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=100)
    latitude=models.CharField(max_length=100)
    longitude=models.CharField(max_length=100)
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)

class exporter(models.Model):
    name=models.CharField(max_length=1900)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=100)
    latitude=models.CharField(max_length=100)
    longitude=models.CharField(max_length=100)
    status=models.CharField(max_length=100)
    proof=models.CharField(max_length=100)
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)


class review(models.Model):
    FARMER=models.ForeignKey(farmer,on_delete=models.CASCADE)
    EXPORT=models.ForeignKey(exporter,on_delete=models.CASCADE)
    review=models.CharField(max_length=100)
    rating=models.CharField(max_length=100)
    date=models.CharField(max_length=100)

class chat(models.Model):
    FARMER = models.ForeignKey(farmer, on_delete=models.CASCADE)
    EXPORT = models.ForeignKey(exporter, on_delete=models.CASCADE)
    message = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    date = models.CharField(max_length=100)


class crop_fertilizer_pesticides(models.Model):
    name = models.CharField(max_length=100)
    details = models.CharField(max_length=100)
    photo = models.CharField(max_length=100)
    price = models.CharField(max_length=100)
    type=models.CharField(max_length=100)

class requirement(models.Model):
    product = models.CharField(max_length=100)
    need = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    description = models.CharField(max_length=100)
    required_date = models.CharField(max_length=100)
    EXPORT = models.ForeignKey(exporter, on_delete=models.CASCADE)


class feedback(models.Model):
    FARMER = models.ForeignKey(farmer, on_delete=models.CASCADE)
    feedback = models.CharField(max_length=100)
    date = models.CharField(max_length=100)

class notification(models.Model):
    date = models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    notification = models.CharField(max_length=100)

class policy(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=100)
    file = models.CharField(max_length=100)
    date = models.CharField(max_length=100)

class product(models.Model):
    FARMER = models.ForeignKey(farmer, on_delete=models.CASCADE)
    product = models.CharField(max_length=100)
    image = models.CharField(max_length=100)
    description = models.CharField(max_length=100)
    quantity = models.CharField(max_length=100)
    base_price = models.CharField(max_length=100)
    date = models.CharField(max_length=100)
    status = models.CharField(max_length=100)

class requirement_availability(models.Model):
    REQUIREMENT=models.ForeignKey(requirement, on_delete=models.CASCADE)
    FARMER = models.ForeignKey(farmer, on_delete=models.CASCADE)
    quantity = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    date = models.CharField(max_length=100)


class bid_amount(models.Model):
    EXPORT=models.ForeignKey(exporter,on_delete=models.CASCADE)
    amount = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    date = models.CharField(max_length=100)
