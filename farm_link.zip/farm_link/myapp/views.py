import datetime
from django.contrib.auth import authenticate, login
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User, Group
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

# Create your views here.
# admin1234
# admin1234
from myapp.models import *


def login1(request):
    return render(request,'login.html')

def login1_post(request):
    un=request.POST['textfield']
    psw=request.POST['textfield2']
    data=authenticate(request,username=un,password=psw)
    if data is not None:
        login(request,data)
        if data.is_superuser:
            return HttpResponse("<script>alert('success');window.location='/admin_home'</script>")
        if data.groups.filter(name='farmer').exists():
            request.session['fid']=farmer.objects.get(LOGIN=request.user.id).id
            return HttpResponse("<script>alert('success');window.location='/farmer_home'</script>")
    return HttpResponse("<script>alert('invalid');window.location='/'</script>")

def admin_home(request):
    return render(request,'admin/admin_home.html')

def farmer_home(request):
    return render(request,'farmer/farmer_home.html')


def export_reg(request):
    na=request.POST['na']
    em=request.POST['em']
    ph=request.POST['ph']
    pl=request.POST['pl']
    post=request.POST['post']
    pin=request.POST['pin']
    lat=request.POST['lat']
    long=request.POST['long']
    psw=request.POST['psw']
    cpsw=request.POST['cpsw']
    file=request.FILES['file']
    fs=FileSystemStorage()
    im=fs.save(file.name,file)

    if psw==cpsw:
        ob=User()
        ob.username=em
        ob.password=make_password(psw)
        ob.save()
        ob.groups.add(Group.objects.get(name='exporter'))

        obj=exporter()
        obj.name=na
        obj.email=em
        obj.phone=ph
        obj.place=pl
        obj.post=post
        obj.pin=pin
        obj.latitude=lat
        obj.longitude=long
        obj.proof=fs.url(im)
        obj.status='pending'
        obj.LOGIN=ob
        obj.save()
        return JsonResponse({'status':'ok'})
    return JsonResponse({'status': 'invalid'})


def view_exporter(request):
    data=exporter.objects.filter(status='pending')
    return render(request,'admin/view_exporter.html',{'data':data})

def approve_exporter(request,id):
    exporter.objects.filter(id=id).update(status='approve')
    return HttpResponse("<script>alert('approved');window.location='/view_exporter'</script>")


def reject_exporter(request,id):
    exporter.objects.filter(id=id).update(status='reject')
    return HttpResponse("<script>alert('rejected');window.location='/view_exporter'</script>")

def view_verified_exporter(request):
    data = exporter.objects.filter(status='approve')
    return render(request, 'admin/view_verified_exporter.html', {'data': data})

def add_notification(request):
    return render(request,'admin/add_notification.html')

def add_notification_post(request):
    t=request.POST['textfield']
    n=request.POST['textfield2']
    obj=notification()
    obj.title=t
    obj.notification=n
    obj.date=datetime.date.today()
    obj.save()
    return HttpResponse("<script>alert('added');window.location='/add_notification'</script>")

def view_notification(request):
    data=notification.objects.all()
    return render(request,'admin/view_notification.html',{'data':data})

def delete_notification(request,id):
    data=notification.objects.get(id=id)
    data.delete()
    return HttpResponse("<script>alert('deleted');window.location='/view_notification'</script>")

def farmer_reg(request):
    return render(request,'farmer/register.html')

def farmer_reg_post(request):
    na = request.POST['textfield']
    em = request.POST['textfield2']
    ph = request.POST['textfield3']
    hn = request.POST['textfield4']
    pl = request.POST['textfield5']
    post = request.POST['textfield6']
    pin = request.POST['textfield7']
    lat = request.POST['textfield8']
    long = request.POST['textfield9']
    psw = request.POST['textfield10']
    cpsw = request.POST['textfield11']

    if psw == cpsw:
        ob = User()
        ob.username = em
        ob.password = make_password(psw)
        ob.save()
        ob.groups.add(Group.objects.get(name='farmer'))

        obj = farmer()
        obj.name = na
        obj.email = em
        obj.phone = ph
        obj.place = pl
        obj.post = post
        obj.house_name=hn
        obj.pin = pin
        obj.latitude = lat
        obj.longitude = long
        obj.LOGIN = ob
        obj.save()
        return HttpResponse("<script>alert('registered successfully');window.location='/'</script>")
    return HttpResponse("<script>alert('password mismatch');window.location='/farmer_reg'</script>")

def farmer_view_notification(request):
    data=notification.objects.all()
    return render(request,'farmer/view_notification.html',{'data':data})

def view_crops(request):
    data=crop_fertilizer_pesticides.objects.filter(type='crop')
    return render(request,'farmer/view_crops_fer.html',{'data':data})

def view_fertilizer(request):
    data=crop_fertilizer_pesticides.objects.filter(type='fertilizer')
    return render(request,'farmer/view_fertilizer.html',{'data':data})

def view_pesticides(request):
    data=crop_fertilizer_pesticides.objects.filter(type='pesticide')
    return render(request,'farmer/view_crops_fer.html',{'data':data})

def add_government_policies(request):
    return render(request,'admin/add_policy.html')

def add_government_policies_post(request):
    na=request.POST['textfield']
    des=request.POST['textarea']
    file=request.FILES['fileField']
    fs=FileSystemStorage()
    im=fs.save(file.name,file)
    obj=policy()
    obj.name=na
    obj.description=des
    obj.file=fs.url(im)
    obj.dat=datetime.date.today()
    obj.save()
    return HttpResponse("<script>alert(' added');window.location='/add_government_policies'</script>")

def admin_view_policy(request):
    data=policy.objects.all()
    return render(request,'admin/view_policy.html',{'data':data})

def edit_policy(request,id):
    data=policy.objects.get(id=id)
    return render(request,'admin/edit_policy.html',{'data':data})

def edit_policy_post(request,id):
    na = request.POST['textfield']
    des = request.POST['textarea']
    file = request.FILES['fileField']
    if 'fileField' in request.FILES:
        fs=FileSystemStorage()
        im=fs.save(file.name,file)
        policy.objects.filter(id=id).update(file=fs.url(im))
    policy.objects.filter(id=id).update(name=na,description=des)
    return HttpResponse("<script>alert('edited');window.location='/admin_view_policy'</script>")

def delete_policy(request,id):
    data=policy.objects.get(id=id)
    data.delete()
    return HttpResponse("<script>alert('deleted');window.location='/admin_view_policy'</script>")

def farmer_view_policy(request):
    data=policy.objects.all()
    return render(request,'farmer/farmer_view-policy.html',{'data':data})

def login2(request):
    un=request.POST['un']
    psw=request.POST['psw']
    data=authenticate(request,username=un,password=psw)
    if data is not None:
        login(request,data)
        if data.groups.filter(name='exporter').exists():
            uid=exporter.objects.get(LOGIN=request.user.id).id
            return JsonResponse({'status':'ok','uid':uid})
        return JsonResponse({"status":'invalid'})
    return JsonResponse({'status':'invalid'})

def exporter_view_profile(request):
    uid=request.POST['uid']
    data=exporter.objects.filter(id=uid)
    ar=[]
    for i in data:
        ar.append({'id':i.id,'name':i.name,'email':i.email,'phone':i.phone,
                   'place':i.place,'post':i.post,'pin':i.pin,'latitude':i.latitude,'longitude':i.longitude,'proof':i.proof})
    return JsonResponse({'status':'ok','data':ar})

def exporter_edit_profile(request):
    id=request.POST['id']
    na = request.POST['na']
    em = request.POST['em']
    ph = request.POST['ph']
    pl = request.POST['pl']
    post = request.POST['post']
    pin = request.POST['pin']
    lat = request.POST['lat']
    long = request.POST['long']
    file = request.FILES['file']
    if 'file' in request.FILES:
        fs=FileSystemStorage()
        im=fs.save(file.name,file)
        exporter.objects.filter(id=id).update(proof=fs.url(im))
    exporter.objects.filter(id=id).update(name=na,email=em,phone=ph,place=pl,post=post,pin=pin,latitude=lat,longitude=long)
    return JsonResponse({'status':'ok'})

def add_requirement(request):
    uid=request.POST['uid']
    prod=request.POST['product']
    need=request.POST['need']
    des=request.POST['des']
    date=request.POST['date']
    obj=requirement()
    obj.product=prod
    obj.need=need
    obj.description=des
    obj.EXPORT_id=uid
    obj.required_date=date
    obj.save()
    return JsonResponse({'status':'ok'})

def view_requirement(request):
    uid=request.POST['uid']
    data=requirement.objects.filter(EXPORT_id=uid)
    ar=[]
    for i in data:
        ar.append({'id':i.id,'product':i.product,'need':i.need,
                   'description':i.description,'require_date':i.required_date})
    return JsonResponse({'status':'ok','data':ar})

def edit_requirement(request):
    id=request.POST['id']
    prod=request.POST['product']
    need = request.POST['need']
    des = request.POST['des']
    date = request.POST['date']
    requirement.objects.filter(id=id).update(
        product=prod,need=need,description=des,required_date=date
    )
    return JsonResponse({'status':'ok'})

def delete_requirement(request):
    id=request.POST['id']
    data=requirement.objects.get(id=id)
    data.delete()
    return JsonResponse({'status':'ok'})

def farmer_view_requirement(request):
    data=requirement.objects.all()
    return render(request,'farmer/view_requirement.html',{'data':data})

def send_availabilty(request,id):
    return render(request,'farmer/send_availability.html',{'id':id})

def send_availabilty_post(request,id):
    q=request.POST['textfield']
    obj=requirement_availability()
    obj.quantity=q
    obj.status='completed'
    obj.FARMER_id=request.session['fid']
    obj.REQUIREMENT_id=id
    obj.save()
    return HttpResponse("<script>alert('added');window.location='/farmer_view_requirement'</script>")

# def exporter_view_availability(request):
#     id=request.POST['id']
#     uid=request.POST['uid']
#     data=requirement_availability.objects.filter(FARMER_id=uid)
#     ar=[]
#     for i in data:
#         ar.append({'id':i.id,''})