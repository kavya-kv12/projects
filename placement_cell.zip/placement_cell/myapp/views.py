import datetime
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth.models import User, Group
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

# Create your views here.
from myapp.models import *


def login1(request):
    return render(request,'login.html')

def login1_post(request):
    un=request.POST['textfield2']
    psw=request.POST['textfield']
    data=authenticate(request,username=un,password=psw)
    print(data)
    if data is not None:
        login(request,data)
        if data.is_superuser:
            return HttpResponse("<script>alert('success');window.location='/admin_home'</script>")
        if data.groups.filter(name='company').exists():
            request.session['cid']=company.objects.get(LOGIN=request.user.id).id
            return HttpResponse("<script>alert('success');window.location='/company_home'</script>")
    return HttpResponse("invalid")

# user=admin
# password=admin1234

def admin_home(request):
    return render(request,'admin/admin_home.html')

def company_registration(request):
    return render(request,'company/registration.html')

def company_registration_post(request):
    na=request.POST['textfield']
    em=request.POST['textfield2']
    ph=request.POST['textfield3']
    pl=request.POST['textfield4']
    po=request.POST['textfield5']
    pi=request.POST['textfield6']
    loc=request.POST['textfield7']
    lat=request.POST['textfield8']
    lon=request.POST['textfield9']
    bio=request.POST['textarea']
    li=request.FILES['fileField']
    fs=FileSystemStorage()
    im=fs.save(li.name,li)
    pho=request.FILES['fileField2']
    fss=FileSystemStorage()
    img=fss.save(pho.name,pho)
    psw=request.POST['textfield10']

    if User.objects.filter(username=em).exists():
        return HttpResponse("<script>alert('already exist');window.location='/company_registration'</script>")

    ob=User()
    ob.username=em
    ob.password=make_password(psw)
    ob.save()
    ob.groups.add(Group.objects.get(name='company'))

    obj=company()
    obj.name=na
    obj.email=em
    obj.phone=ph
    obj.place=pl
    obj.post=po
    obj.pin=pi
    obj.location=loc
    obj.latitude=lat
    obj.location=lon
    obj.bio=bio
    obj.license=fs.url(im)
    obj.photo=fss.url(img)
    obj.status='pending'
    obj.LOGIN=ob
    obj.save()
    return HttpResponse("<script>alert('successfully registered');window.location='/'</script>")

def view_verify_company(request):
    data=company.objects.filter(status='pending')
    return render(request,'admin/view_verify_company.html',{'data':data})

def approve_company(request,id):
    company.objects.filter(id=id).update(status='approve')
    return HttpResponse("<script>alert('approved');window.location='/view_verify_company'</script>")

def reject_company(request,id):
    company.objects.filter(id=id).update(status='reject')
    return HttpResponse("<script>alert('rejected');window.location='/view_verify_company'</script>")

def view_verified_company(request):
    data=company.objects.filter(status='approve')
    return render(request,'admin/verified-company.html',{'data':data})

def user_reg(request):
    na=request.POST['na']
    em=request.POST['em']
    ph=request.POST['ph']
    ho=request.POST['ho']
    pl=request.POST['pl']
    po=request.POST['po']
    pi=request.POST['pi']
    co=request.POST['co']
    se=request.POST['se']
    ba=request.POST['ba']
    psw=request.POST['pass']

    if User.objects.filter(username=em).exists():
        return JsonResponse({'status':'error'})

    ob=User()
    ob.username=em
    ob.password=make_password(psw)
    ob.save()
    ob.groups.add(Group.objects.get(name='candidate'))

    obj=student()
    obj.name=na
    obj.email=em
    obj.phone=ph
    obj.housename=ho
    obj.place=pl
    obj.post=po
    obj.pin=pi
    obj.course=co
    obj.sem=se
    obj.batch=ba
    obj.LOGIN=ob
    obj.save()
    return JsonResponse({'status':'ok'})

def login2(request):
    un=request.POST['un']
    psw=request.POST['p']
    data=authenticate(request,username=un,password=psw)
    print(un,psw)
    if data is not None:
        login(request,data)
        if data.groups.filter(name="candidate").exists():
            uid = student.objects.get(LOGIN=request.user.id).id
            return JsonResponse({'status':'ok',"uid":uid})
    return JsonResponse({'status':'not found'})


def admin_view_candidate(request):
    data=student.objects.all()
    return render(request,'admin/view_candidates.html',{'data':data})

def company_home(request):
    return  render(request,'company/company_home.html')

def add_vaccancy(request):
    return render(request,'company/add_vaccancy.html')

def add_vaccancy_post(request):
    job=request.POST['textfield']
    fro=request.POST['textfield2']
    to=request.POST['textfield3']
    des=request.POST['textarea']
    num=request.POST['textfield4']

    obj=vaccancy()
    obj.jobtitle=job
    obj.apply_from_date=fro
    obj.apply_to_date=to
    obj.description=des
    obj.number_of_vaccancy=num
    obj.COMPANY_id=request.session['cid']
    obj.save()
    return HttpResponse("<script>alert('added');window.location='/add_vaccancy'</script>")

def comp_view_vaccancy(request):
    data=vaccancy.objects.filter(COMPANY_id=request.session['cid'])
    return render(request,'company/view_vaccancy.html',{'data':data})

def edit_vaccancy(request,id):
    data=vaccancy.objects.get(id=id)
    return render(request,'company/edit_vaccancy.html',{'data':data})

def edit_vaccancy_post(request,id):
    job = request.POST['textfield']
    fro = request.POST['textfield2']
    to = request.POST['textfield3']
    des = request.POST['textarea']
    num = request.POST['textfield4']
    vaccancy.objects.filter(id=id).update(jobtitle=job,apply_from_date=fro,apply_to_date=to,description=des,number_of_vaccancy=num)
    return HttpResponse("<script>alert('edited');window.location='/comp_view_vaccancy'</script>")

def delete_vaccancy(request,id):
    data=vaccancy.objects.get(id=id)
    data.delete()
    return HttpResponse("<script>alert('deleted');window.location='/comp_view_vaccancy'</script>")


def add_schedule(request,id):
    return render(request, 'company/schedule_test.html',{'id':id})


def add_schedule_post(request,id):
    fr=request.POST['textfield']
    to=request.POST['textfield2']
    num=request.POST['textfield3']
    obj=vaccancy_schedule_test()
    obj.from_time=fr
    obj.to_time=to
    obj.number_of_students=num
    obj.VACCANCY_id=id
    obj.date=datetime.date.today()
    obj.save()
    return HttpResponse("<script>alert('added');window.location='/comp_view_vaccancy'</script>")

def view_schedule(request,id):
    data=vaccancy_schedule_test.objects.filter(id=id)
    return  render(request,'company/view_schedule.html',{'data':data})

def add_question(request,id):
    return render(request,'company/add_question.html',{'id':id})

def add_question_post(request,id):
    que=request.POST['textfield']
    op1=request.POST['textfield2']
    op2=request.POST['textfield3']
    op3=request.POST['textfield4']
    op4=request.POST['textfield5']
    correct=request.POST['textfield6']
    obj=question()
    obj.question=que
    obj.option1=op1
    obj.option2=op2
    obj.option3=op3
    obj.option4=op4
    obj.correct_answer=correct
    obj.SCHEDULE_TEST_id=id
    obj.save()
    return HttpResponse("<script>alert('added');window.location='/view_schedule/"+id+"'</script>")

def view_question(request,id):
    data=question.objects.filter(id=id)
    return render(request,'company/view_question.html',{'data':data})

def edit_question(request,id):
    data=question.objects.get(id=id)
    return render(request,'company/edit_question.html',{'data':data})

def edit_question_post(request,id):
    que = request.POST['textfield']
    op1 = request.POST['textfield2']
    op2 = request.POST['textfield3']
    op3 = request.POST['textfield4']
    op4 = request.POST['textfield5']
    correct = request.POST['textfield6']
    question.objects.filter(id=id).update(question=que,option1=op1,option2=op2,option3=op3,option4=op4,correct_answer=correct)
    return HttpResponse("<script>alert('edited');window.location='/view_question/"+id+"'</script>")


def cand_view_vaccancy(request):
    data=vaccancy.objects.all()
    ar=[]
    for i in data:
        ar.append({'id':i.id,'jobtitle':i.jobtitle,'from_date':i.apply_from_date,'to_date':i.apply_to_date,'description':i.description,'number_of_vaccancy':i.number_of_vaccancy})
    return  JsonResponse({'status':'ok','data':ar})

def send_request(request):
    id=request.POST['id']
    uid=request.POST['uid']
    obj=vaccancy_request()
    obj.STUDENT_id=uid
    obj.VACCANCY_id=id
    obj.status='pending'
    obj.date=datetime.date.today()
    obj.save()
    return JsonResponse({"status":'ok'})

def view_vaccancy_request(request):
    data=vaccancy_request.objects.filter(VACCANCY__COMPANY_id=request.session['cid'])
    return render(request,'company/view_vaccancy_request.html',{'data':data})

def send_complaint(request):
    uid=request.POST['uid']
    comp=request.POST['comp']
    obj=complaint()
    obj.complaint=comp
    obj.comp_date=datetime.date.today()
    obj.STUDENT_id=uid
    obj.save()
    return JsonResponse({'status':'ok'})

def view_applied_list(request):
    uid=request.POST['uid']
    data=vaccancy_request.objects.filter(STUDENT_id=uid)
    ar=[]
    for i in data:
        ar.append({'id':i.id,'vaccancy':i.VACCANCY.jobtitle,'date':i.date,'status':i.status})

    return JsonResponse({'status':'ok','data':ar})

def view_complaint(request):
    data=complaint.objects.all()
    return render(request,'admin/view_complaint.html',{'data':data})

def send_reply(request,id):
    return render(request,'admin/send_reply.html',{'id':id})

def send_reply_post(request,id):
    rep=request.POST['textarea']
    complaint.objects.filter(id=id).update(reply=rep,reply_date=datetime.date.today())
    return HttpResponse("<script>alert('send');window.location='/view_complaint'</script>")

def view_reply(request):
    uid=request.POST['uid']
    data=complaint.objects.filter(STUDENT_id=uid)
    ar=[]
    for i in data:
        ar.append({'id':i.id,'reply':i.reply,'reply_date':i.reply_date})
    return JsonResponse({"status":'ok','data':ar})

def send_review(request):
    data=company.objects.all()
    ar=[]
    for i in data:
        ar.append({'id':i.id,'name':i.name,'email':i.email,'phone':i.phone,'place':i.place,'photo':i.photo,'bio':i.bio,'license':i.license})
    return JsonResponse({'status':'ok','data':ar})


def send_feedback(request):
    uid=request.POST['uid']
    feed=request.POST['feed']
    obj=feedback()
    obj.feedback=feed
    obj.feedback_date=datetime.date.today()
    obj.STUDENT_id=uid
    obj.save()
    return JsonResponse({'status':'ok'})

def reviews(request):
    uid=request.POST['uid']
    cid=request.POST['cid']
    rev=request.POST['rev']
    obj=review()
    obj.review=rev
    obj.STUDENT_id=uid
    obj.COMPANY_id=cid
    obj.save()
    return JsonResponse({'status':'ok'})

def view_review(request):
    data=review.objects.all()
    return render(request,'admin/view_review.html',{'data':data})

def view_feedback(request):
    data=feedback.objects.all()
    return render(request,'admin/view_feedback.html',{'data':data})

def company_view_review(request):
    data=review.objects.filter(COMPANY_id=request.session['cid'])
    return render(request,'company/view_review.html',{'data':data})

def admin_change_password(request):
    return render(request,'admin/change_password.html')

def admin_change_password_post(request):
    old=request.POST['textfield']
    new=request.POST['textfield2']
    conf=request.POST['textfield3']
    if new == conf:
        res=check_password(old,request.user.password)
        if res:
            user=request.user
            user.set_password(new)
            user.save()
            logout(request)
        return HttpResponse("<script>alert('updated');window.location='/'</script>")
    return HttpResponse("<script>alert('password mismatch');window.location='/admin_change_password'</script>")

def company_change_password(request):
    return render(request,'admin/change_password.html')

def company_change_password_post(request):
    old=request.POST['textfield']
    new=request.POST['textfield2']
    conf=request.POST['textfield3']
    if new == conf:
        res=check_password(old,request.user.password)
        if res:
            user=request.user
            user.set_password(new)
            user.save()
            logout(request)
        return HttpResponse("<script>alert('updated');window.location='/'</script>")
    return HttpResponse("<script>alert('password mismatch');window.location='/company_change_password'</script>")

def student_change_password(request):
    uid=request.POST['uid']
    new=request.POST['new']
    lid=student.objects.get(id=uid).LOGIN_id
    User.objects.filter(id=lid).update(password=make_password(new))


