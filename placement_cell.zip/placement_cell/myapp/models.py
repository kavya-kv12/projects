from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class company(models.Model):
    name=models.CharField(max_length=100)
    location=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=100)
    latitude=models.CharField(max_length=100)
    longitude=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    bio=models.CharField(max_length=100)
    photo=models.CharField(max_length=100)
    license=models.CharField(max_length=100)
    status=models.CharField(max_length=100)
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)

class student(models.Model):
    name = models.CharField(max_length=100)
    housename = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    pin = models.CharField(max_length=100)
    course = models.CharField(max_length=100)
    sem = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    batch = models.CharField(max_length=100)
    LOGIN = models.ForeignKey(User,on_delete=models.CASCADE)

class vaccancy(models.Model):
    COMPANY=models.ForeignKey(company,on_delete=models.CASCADE)
    jobtitle = models.CharField(max_length=100)
    apply_from_date = models.CharField(max_length=100)
    apply_to_date = models.CharField(max_length=100)
    description = models.CharField(max_length=100)
    cut_off = models.CharField(max_length=100)
    number_of_vaccancy = models.CharField(max_length=100)

class vaccancy_schedule_test(models.Model):
    VACCANCY=models.ForeignKey(vaccancy,on_delete=models.CASCADE)
    date=models.CharField(max_length=100)
    from_time=models.CharField(max_length=100)
    to_time=models.CharField(max_length=100)
    number_of_students=models.CharField(max_length=100)

class vaccancy_request(models.Model):
    VACCANCY=models.ForeignKey(vaccancy,on_delete=models.CASCADE)
    STUDENT=models.ForeignKey(student,on_delete=models.CASCADE)
    status=models.CharField(max_length=100)
    date=models.CharField(max_length=100)

class exam_allocate(models.Model):
    VACCANCY_REQUEST=models.ForeignKey(vaccancy_request,on_delete=models.CASCADE)
    SCHEDULE_TEST=models.ForeignKey(vaccancy_schedule_test,on_delete=models.CASCADE)

class question(models.Model):
    SCHEDULE_TEST=models.ForeignKey(vaccancy_schedule_test,on_delete=models.CASCADE)
    question=models.CharField(max_length=100)
    option1=models.CharField(max_length=100)
    option2=models.CharField(max_length=100)
    option3=models.CharField(max_length=100)
    option4=models.CharField(max_length=100)
    correct_answer=models.CharField(max_length=100)

class exam(models.Model):
    VACCANCY_REQUEST=models.ForeignKey(vaccancy_request,on_delete=models.CASCADE)
    QUESTION=models.ForeignKey(question,on_delete=models.CASCADE)

class cv(models.Model):
    STUDENT=models.ForeignKey(student,on_delete=models.CASCADE)
    file=models.CharField(max_length=100)

class review(models.Model):
    review=models.CharField(max_length=100)
    STUDENT=models.ForeignKey(student,on_delete=models.CASCADE)
    COMPANY=models.ForeignKey(company,on_delete=models.CASCADE)

class complaint(models.Model):
    complaint=models.CharField(max_length=100)
    comp_date=models.CharField(max_length=100)
    reply=models.CharField(max_length=100)
    reply_date=models.CharField(max_length=100)
    STUDENT=models.ForeignKey(student,on_delete=models.CASCADE)

class feedback(models.Model):
    feedback=models.CharField(max_length=100)
    feedback_date=models.CharField(max_length=100)
    STUDENT=models.ForeignKey(student,on_delete=models.CASCADE)
