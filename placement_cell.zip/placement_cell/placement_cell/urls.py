"""placement_cell URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path

from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.login1),
    path('login1_post',views.login1_post),
    path('admin_home',views.admin_home),
    path('company_registration',views.company_registration),
    path('company_registration_post',views.company_registration_post),
    path('view_verify_company',views.view_verify_company),
    path('approve_company/<id>',views.approve_company),
    path('reject_company/<id>',views.reject_company),
    path('view_verified_company',views.view_verified_company),
    path('user_reg',views.user_reg),
    path('login2',views.login2),
    path('admin_view_candidate',views.admin_view_candidate),
    path('company_home',views.company_home),
    path('add_vaccancy',views.add_vaccancy),
    path('add_vaccancy_post',views.add_vaccancy_post),
    path('comp_view_vaccancy',views.comp_view_vaccancy),
    path('edit_vaccancy/<id>',views.edit_vaccancy),
    path('edit_vaccancy_post/<id>',views.edit_vaccancy_post),
    path('delete_vaccancy/<id>',views.delete_vaccancy),
    path('cand_view_vaccancy',views.cand_view_vaccancy),
    path('send_request',views.send_request),
    path('view_vaccancy_request',views.view_vaccancy_request),
    path('add_schedule/<id>',views.add_schedule),
    path('add_schedule_post/<id>',views.add_schedule_post),
    path('view_schedule/<id>',views.view_schedule),
    path('add_question/<id>',views.add_question),
    path('add_question_post/<id>',views.add_question_post),
    path('view_question/<id>',views.view_question),
    path('edit_question/<id>',views.edit_question),
    path('edit_question_post/<id>',views.edit_question_post),
    path('send_complaint',views.send_complaint),
    path('view_applied_list',views.view_applied_list),
    path('view_complaint',views.view_complaint),
    path('send_reply/<id>',views.send_reply),
    path('send_reply_post/<id>',views.send_reply_post),
    path('view_reply',views.view_reply),
    path('send_review',views.send_review),
    path('send_feedback',views.send_feedback),
    path('reviews',views.reviews),
    path('view_review',views.view_review),
    path('view_feedback',views.view_feedback),
    path('company_view_review',views.company_view_review),
    path('admin_change_password',views.admin_change_password),
    path('admin_change_password_post',views.admin_change_password_post),
    path('company_change_password',views.company_change_password),
    path('company_change_password_post',views.company_change_password_post),
    path('student_change_password',views.student_change_password),

]

urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)