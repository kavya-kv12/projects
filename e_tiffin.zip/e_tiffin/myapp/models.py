from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class tiffin_provider(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    proof=models.CharField(max_length=100)
    location=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=100)
    latitude=models.CharField(max_length=100)
    longitude=models.CharField(max_length=100)
    status=models.CharField(max_length=100)
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)

class user(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=100)
    latitude=models.CharField(max_length=100)
    longitude=models.CharField(max_length=100)
    location=models.CharField(max_length=100)
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)

class food_category(models.Model):
    name=models.CharField(max_length=100)

class menu(models.Model):
    menu=models.CharField(max_length=100)
    photo=models.CharField(max_length=100)
    quantity=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    FOOD_CATEGORY=models.ForeignKey(food_category,on_delete=models.CASCADE)
    TIFFIN=models.ForeignKey(tiffin_provider,on_delete=models.CASCADE)

class subscription(models.Model):
    duration=models.CharField(max_length=100)
    amount=models.CharField(max_length=100)
    TIFFIN=models.ForeignKey(tiffin_provider,on_delete=models.CASCADE)

class subscription_menu(models.Model):
    quantity=models.CharField(max_length=100)
    SUBSCRIPTION=models.ForeignKey(subscription,on_delete=models.CASCADE)
    MENU=models.ForeignKey(menu,on_delete=models.CASCADE)

class feedback(models.Model):
    feedback=models.CharField(max_length=100)
    date=models.CharField(max_length=100)
    USER=models.ForeignKey(user,on_delete=models.CASCADE)

class subscription_request(models.Model):
    USER=models.ForeignKey(user,on_delete=models.CASCADE)
    SUBSCRIPTION=models.ForeignKey(subscription,on_delete=models.CASCADE)
    from_date=models.CharField(max_length=100)
    to_date=models.CharField(max_length=100)
    payment_mode=models.CharField(max_length=100)
    date=models.CharField(max_length=100)
    status=models.CharField(max_length=100)

class daily_request(models.Model):
    date=models.CharField(max_length=100)
    amount=models.CharField(max_length=100)
    status=models.CharField(max_length=100)
    payment_mode=models.CharField(max_length=100)
    USER=models.ForeignKey(user,on_delete=models.CASCADE)
    TIFFIN=models.ForeignKey(tiffin_provider,on_delete=models.CASCADE)

class daily_request_menu(models.Model):
    quantity=models.CharField(max_length=100)
    MENU=models.ForeignKey(menu,on_delete=models.CASCADE)
    DAILY_REQUEST=models.ForeignKey(daily_request,on_delete=models.CASCADE)

class cart(models.Model):
    quantity=models.CharField(max_length=100)
    USER=models.ForeignKey(user,on_delete=models.CASCADE)
    MENU=models.ForeignKey(menu,on_delete=models.CASCADE)

class rating(models.Model):
    USER=models.ForeignKey(user,on_delete=models.CASCADE)
    TIFFIN=models.ForeignKey(tiffin_provider,on_delete=models.CASCADE)
    review=models.CharField(max_length=100)
    # rating=models.CharField(max_length=100)
    date=models.CharField(max_length=100)
