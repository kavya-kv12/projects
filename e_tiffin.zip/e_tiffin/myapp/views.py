import datetime
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth.models import Group
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

# Create your views here.
# admin1234
# admin1234
from myapp.models import *


def login1(request):
    return render(request,'login.html')

def login1_post(request):
    un=request.POST['textfield']
    psw=request.POST['textfield2']
    data=authenticate(request,username=un,password=psw)
    if data is not None:
        login(request,data)
        if data.is_superuser:
            return HttpResponse("<script>alert('success');window.location='/admin_home'</script>")
        if data.groups.filter(name='tiffin').exists():
            request.session['tid']=tiffin_provider.objects.get(LOGIN=request.user.id).id
            return HttpResponse("<script>alert('success');window.location='/tiffin_home'</script>")
        return HttpResponse("<script>alert('invalid');window.location='/'</script>")
    return HttpResponse("<script>alert('invalid');window.location='/'</script>")


def admin_home(request):
    return render(request,'admin/admin_home.html')

def tiffin_home(request):
    return render(request,'tiffin/tiffin_home.html')

def tiffin_reg(request):
    return render(request,'tiffin/register.html')

def tiffin_reg_post(request):
    na=request.POST['textfield']
    em=request.POST['textfield2']
    ph=request.POST['textfield3']
    pr=request.FILES['fileField']
    fs=FileSystemStorage()
    proof=fs.save(pr.name,pr)
    loc=request.POST['textfield4']
    pl=request.POST['textfield5']
    po=request.POST['textfield6']
    pi=request.POST['textfield7']
    lat=request.POST['textfield8']
    long=request.POST['textfield9']
    psw=request.POST['textfield10']
    conf=request.POST['textfield11']
    if psw==conf:
        ob=User()
        ob.username=em
        ob.password=make_password(psw)
        ob.save()
        ob.groups.add(Group.objects.get(name='tiffin'))

        obj=tiffin_provider()
        obj.name=na
        obj.email=em
        obj.phone=ph
        obj.proof=fs.url(proof)
        obj.location=loc
        obj.place=pl
        obj.post=po
        obj.pin=pi
        obj.latitude=lat
        obj.longitude=long
        obj.status='pending'
        obj.LOGIN=ob
        obj.save()
        return HttpResponse("<script>alert('registered successfully');window.location='/'</script>")

def view_tiffin(request):
    data=tiffin_provider.objects.filter(status='pending')
    return render(request,'admin/view_tiffin.html',{'data':data})

def approve_tiffin(request,id):
    tiffin_provider.objects.filter(id=id).update(status='approve')
    return HttpResponse("<script>alert('approved');window.location='/view_tiffin'</script>")

def reject_tiffin(request,id):
    tiffin_provider.objects.filter(id=id).update(status='reject')
    return HttpResponse("<script>alert('rejected');window.location='/view_tiffin'</script>")

def view_verified_tiffin(request):
    data=tiffin_provider.objects.filter(status='approve')
    return render(request,'admin/verified_tiffin.html',{'data':data})

def add_category(request):
    return render(request,'admin/add_category.html')

def add_category_post(request):
    cat=request.POST['textfield']
    obj=food_category()
    obj.name=cat
    obj.save()
    return HttpResponse("<script>alert('category added');window.location='/add_category'</script>")

def ad_view_category(request):
    data=food_category.objects.all()
    return render(request,'admin/view_category.html',{'data':data})

def delete_category(request,id):
    data=food_category.objects.get(id=id)
    data.delete()
    return HttpResponse("<script>alert('category deleted');window.location='/ad_view_category'</script>")

def tiffin_view_profile(request):
    data=tiffin_provider.objects.filter(id=request.session['tid'])
    return render(request,'tiffin/view_profile.html',{'data':data})

def tiffin_edit_profile(request,id):
    data=tiffin_provider.objects.get(id=id)
    return render(request,'tiffin/edit_profile.html',{'data':data})

def tiffin_edit_profile_post(request,id):
    na = request.POST['textfield']
    em = request.POST['textfield2']
    ph = request.POST['textfield3']
    pr = request.FILES['fileField']
    if 'fileField' in request.FILES:
        fs = FileSystemStorage()
        proof = fs.save(pr.name, pr)
        tiffin_provider.objects.filter(id=id).update(proof=fs.url(proof))
    loc = request.POST['textfield4']
    pl = request.POST['textfield5']
    po = request.POST['textfield6']
    pi = request.POST['textfield7']
    lat = request.POST['textfield8']
    long = request.POST['textfield9']
    tiffin_provider.objects.filter(id=id).update(name=na,email=em,phone=ph,location=loc,
                                                 place=pl,post=po,pin=pi,latitude=lat,longitude=long)
    return HttpResponse("<script>alert('profile edited');window.location='/tiffin_view_profile'</script>")

def tiffin_view_category(request):
    data=food_category.objects.all()
    return render(request,'tiffin/view_category.html',{'data':data})

def add_menu(request,id):
    return render(request,'tiffin/add_menu.html',{'id':id})

def add_menu_post(request,id):
    me=request.POST['textfield']
    pho=request.FILES['fileField']
    fs=FileSystemStorage()
    ph=fs.save(pho.name,pho)
    q=request.POST['textfield2']
    pr=request.POST['textfield3']
    obj=menu()
    obj.FOOD_CATEGORY_id=id
    obj.menu=me
    obj.photo=fs.url(ph)
    obj.quantity=q
    obj.price=pr
    obj.TIFFIN_id=request.session['tid']
    obj.save()
    return HttpResponse("<script>alert('menu added ');window.location='/tiffin_view_category'</script>")

def tiffin_view_menu(request,id):
    data=menu.objects.filter(FOOD_CATEGORY_id=id)
    return render(request,'tiffin/view_menu.html',{'data':data})

def edit_menu(request,id):
    data=menu.objects.get(id=id)
    return render(request,'tiffin/edit_menu.html',{'data':data})

def edit_menu_post(request,id):
    me = request.POST['textfield']
    pho = request.FILES['fileField']
    if 'fileField' in request.FILES:
        fs = FileSystemStorage()
        ph = fs.save(pho.name, pho)
        menu.objects.filter(id=id).update(photo=fs.url(ph))
    q = request.POST['textfield2']
    pr = request.POST['textfield3']
    menu.objects.filter(id=id).update(menu=me,quantity=q,price=pr)
    return HttpResponse("<script>alert('menu edited');window.location='/tiffin_view_menu/"+id+"'</script>")

def delete_menu(request,id):
    data=menu.objects.get(id=id)
    data.delete()
    return HttpResponse("<script>alert('menu deleted');window.location='/tiffin_view_menu/"+id+"'</script>")

def add_subscription(request):
    return render(request,'tiffin/add_subscription.html')

def add_subscription_post(request):
    d=request.POST['textfield']
    a=request.POST['textfield2']
    obj=subscription()
    obj.duration=d
    obj.amount=a
    obj.TIFFIN_id=request.session['tid']
    obj.save()
    return HttpResponse("<script>alert('subscription added');window.location='/add_subscription'</script>")


def tiffin_view_subscription(request):
    data=subscription.objects.filter(id=request.session['tid'])
    return render(request,'tiffin/view_subscription.html',{'data':data})

def edit_subscription(request,id):
    data=subscription.objects.get(id=id)
    return render(request,'tiffin/edit+subscription.html',{"data":data})

def editsubscription_post(request,id):
    d=request.POST['textfield']
    am=request.POST['textfield2']
    subscription.objects.filter(id=id).update(duration=d,amount=am)
    return HttpResponse("<script>alert('subscription edited');window.location='/tiffin_view_subscription'</script>")

def delete_subscription(request,id):
    data=subscription.objects.get(id=id)
    data.delete()
    return HttpResponse("<script>alert('subscription deleted');window.location='/tiffin_view_subscription'</script>")

def user_reg(request):
    na=request.POST['na']
    em=request.POST['em']
    ph=request.POST['ph']
    pl=request.POST['pl']
    po=request.POST['po']
    pi=request.POST['pi']
    lat=request.POST['lat']
    long=request.POST['lon']
    loc=request.POST['loc']
    psw=request.POST['psw']
    con=request.POST['con']
    if psw == con:
        ob=User()
        ob.username=em
        ob.password=make_password(psw)
        ob.save()
        ob.groups.add(Group.objects.get(name='customer'))
        obj=user()
        obj.name=na
        obj.email=em
        obj.phone=ph
        obj.place=pl
        obj.post=po
        obj.pin=pi
        obj.latitude=lat
        obj.longitude=long
        obj.location=loc
        obj.LOGIN=ob
        obj.save()
        return JsonResponse({'status':'ok'})
    return JsonResponse({'status':'invalid'})

def login2(request):
    un=request.POST['un']
    psw=request.POST['psw']
    data=authenticate(request,username=un,password=psw)
    if data is not None:
        login(request,data)
        if data.groups.filter(name='customer').exists():
            uid=user.objects.get(LOGIN=request.user.id).id
            return JsonResponse({'status':'ok','uid':uid})
        return JsonResponse({'status':'invalid'})
    return JsonResponse({'status':'invalid'})

def user_view_profile(request):
    uid=request.POST['uid']
    data=user.objects.filter(id=uid)
    ar=[]
    for i in data:
        ar.append({'id':i.id,'name':i.name,'email':i.email,'phone':i.phone,'place':i.place,
                   'post':i.post,'pin':i.pin,'latitude':i.latitude,'longitude':i.longitude,'location':i.location})
    return JsonResponse({'status':'ok','data':ar})

def user_edit_profile(request):
    id=request.POST['id']
    na = request.POST['na']
    em = request.POST['em']
    ph = request.POST['ph']
    pl = request.POST['pl']
    po = request.POST['po']
    pi = request.POST['pi']
    lat = request.POST['lat']
    long = request.POST['lon']
    loc = request.POST['loc']
    user.objects.filter(id=id).update(name=na,email=em,phone=ph,place=pl,post=po,pin=pi,
                                      latitude=lat,longitude=long,location=loc)
    return JsonResponse({'status':'ok'})


def send_feedback(request):
    feed=request.POST['feed']
    uid=request.POST['uid']
    obj=feedback()
    obj.feedback=feed
    obj.date=datetime.date.today()
    obj.USER_id=uid
    obj.save()
    return JsonResponse({'status':'ok'})

def user_view_tiffin(request):
    data=tiffin_provider.objects.all()
    ar=[]
    for i in data:
        ar.append({'id':i.id,'name':i.name,'email':i.email,'phone':i.phone,'location':i.location,'post':i.post,'place':i.place,
                   'pin':i.pin,'latitude':i.latitude,'longitude':i.longitude,'proof':i.proof})
    return JsonResponse({'status':'ok','data':ar})

def send_review(request):
    uid=request.POST['uid']
    tid=request.POST['tid']
    rev=request.POST['rev']
    obj=rating()
    obj.review=rev
    obj.USER_id=uid
    obj.TIFFIN_id=tid
    obj.date=datetime.date.today()
    print(tid)
    obj.save()
    return JsonResponse({'status':'ok'})

def tiffin_view_review(request):
    data=rating.objects.filter(TIFFIN_id=request.session['tid'])
    return render(request,'tiffin/view_review.html',{'data':data})

def admin_view_feedback(request):
    data=feedback.objects.all()
    return render(request,'admin/view_feedback.html',{'data':data})

def admin_view_review(request):
    data=rating.objects.all()
    return render(request,'admin/view_review.html',{'data':data})

def admin_change_password(request):
    return render(request,'admin/change password.html')

def admin_change_password_post(request):
    old=request.POST['textfield']
    new=request.POST['textfield2']
    conf=request.POST['textfield3']
    if new==conf:
        res=check_password(old,request.user.password)
        if res:
            user=request.user
            user.set_password(new)
            user.save()
            logout(request)
            return HttpResponse("<script>alert('password updated');window.location='/'</script>")
        return HttpResponse("<script>alert('invalid');window.location='/admin_change_password'</script>")
    return HttpResponse("<script>alert('mismatch');window.location='/admin_change_password'</script>")


def tiffin_change_password(request):
    return render(request,'tiffin/change_password.html')

def tiffin_change_password_post(request):
    old = request.POST['textfield']
    new = request.POST['textfield2']
    conf = request.POST['textfield3']
    if new == conf:
        res = check_password(old, request.user.password)
        if res:
            user = request.user
            user.set_password(new)
            user.save()
            logout(request)
            return HttpResponse("<script>alert('password updated');window.location='/'</script>")
        return HttpResponse("<script>alert('invalid');window.location='/tiffin_change_password'</script>")
    return HttpResponse("<script>alert('mismatch');window.location='/tiffin_change_password'</script>")

def admin_view_user(request):
    data=user.objects.all()
    return render(request,'admin/view_user.html',{'data':data})


def user_change_password(request):
    uid=request.POST['uid']
    new=request.POST['new']
    lid=user.objects.get(id=uid).LOGIN_id
    User.objects.filter(id=lid).update(password=make_password(new))
    return JsonResponse({'status':'ok'})

