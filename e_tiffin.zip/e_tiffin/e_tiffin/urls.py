"""e_tiffin URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path

from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.login1),
    path('login1_post',views.login1_post),
    path('admin_home',views.admin_home),
    path('tiffin_home',views.tiffin_home),
    path('tiffin_reg',views.tiffin_reg),
    path('tiffin_reg_post',views.tiffin_reg_post),
    path('view_tiffin',views.view_tiffin),
    path('approve_tiffin/<id>',views.approve_tiffin),
    path('reject_tiffin/<id>',views.reject_tiffin),
    path('view_verified_tiffin',views.view_verified_tiffin),
    path('add_category',views.add_category),
    path('add_category_post',views.add_category_post),
    path('ad_view_category',views.ad_view_category),
    path('delete_category/<id>',views.delete_category),
    path('tiffin_view_profile',views.tiffin_view_profile),
    path('tiffin_edit_profile/<id>',views.tiffin_edit_profile),
    path('tiffin_edit_profile_post/<id>',views.tiffin_edit_profile_post),
    path('tiffin_view_category',views.tiffin_view_category),
    path('add_menu/<id>',views.add_menu),
    path('add_menu_post/<id>',views.add_menu_post),
    path('tiffin_view_menu/<id>',views.tiffin_view_menu),
    path('edit_menu/<id>',views.edit_menu),
    path('edit_menu_post/<id>',views.edit_menu_post),
    path('delete_menu/<id>',views.delete_menu),
    path('add_subscription',views.add_subscription),
    path('add_subscription_post',views.add_subscription_post),
    path('tiffin_view_subscription',views.tiffin_view_subscription),
    path('edit_subscription/<id>',views.edit_subscription),
    path('editsubscription_post/<id>',views.editsubscription_post),
    path('delete_subscription/<id>',views.delete_subscription),
    path('user_reg',views.user_reg),
    path('login2',views.login2),
    path('user_view_profile',views.user_view_profile),
    path('user_edit_profile',views.user_edit_profile),
    path('send_feedback',views.send_feedback),
    path('user_view_tiffin',views.user_view_tiffin),
    path('send_review',views.send_review),
    path('tiffin_view_review',views.tiffin_view_review),
    path('admin_view_feedback',views.admin_view_feedback),
    path('admin_view_review',views.admin_view_review),
    path('admin_change_password',views.admin_change_password),
    path('admin_change_password_post',views.admin_change_password_post),
    path('tiffin_change_password',views.tiffin_change_password),
    path('tiffin_change_password_post',views.tiffin_change_password_post),
    path('admin_view_user',views.admin_view_user),
    path('user_change_password',views.user_change_password),

]
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
